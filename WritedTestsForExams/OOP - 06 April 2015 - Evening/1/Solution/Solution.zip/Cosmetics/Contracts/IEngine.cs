﻿namespace Cosmetics.Contracts
{
    public interface IEngine
    {
        void Start();
    }
}
